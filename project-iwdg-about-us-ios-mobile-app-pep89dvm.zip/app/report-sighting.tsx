import { View, Text, ScrollView, StyleSheet, TextInput, TouchableOpacity, Alert, Platform, Image } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useState, useEffect } from 'react';
import { Eye, MapPin, Calendar, Camera, WifiOff } from 'lucide-react-native';
import * as Linking from 'expo-linking';
import * as Location from 'expo-location';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import { useOfflineReports } from '../hooks/useOfflineReports';
import { OfflineQueue } from '../components/OfflineQueue';
import { OfflineStatus } from '../components/OfflineStatus';

export default function ReportSightingScreen() {
  const [observer, setObserver] = useState('');
  const [email, setEmail] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [location, setLocation] = useState('');
  const [coordinates, setCoordinates] = useState('');
  const [species, setSpecies] = useState('');
  const [count, setCount] = useState('1');
  const [notes, setNotes] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const [locationPermission, setLocationPermission] = useState<boolean | null>(null);
  const [cameraPermission, setCameraPermission] = useState<boolean | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { queueReport, isOnline, hasQueuedReports } = useOfflineReports();

  useEffect(() => {
    checkPermissions();
  }, []);

  const checkPermissions = async () => {
    // Check location permissions
    const { status: locationStatus } = await Location.requestForegroundPermissionsAsync();
    setLocationPermission(locationStatus === 'granted');

    // Check camera permissions
    const { status: cameraStatus } = await ImagePicker.requestCameraPermissionsAsync();
    setCameraPermission(cameraStatus === 'granted');
  };

  const getCurrentLocation = async () => {
    if (locationPermission) {
      try {
        const location = await Location.getCurrentPositionAsync({});
        const { latitude, longitude } = location.coords;
        setCoordinates(`${latitude.toFixed(6)}, ${longitude.toFixed(6)}`);
        
        // Reverse geocode to get address
        const reverseGeocode = await Location.reverseGeocodeAsync({ latitude, longitude });
        if (reverseGeocode.length > 0) {
          const address = reverseGeocode[0];
          const locationString = [address.name, address.city, address.region, address.country]
            .filter(Boolean)
            .join(', ');
          setLocation(locationString);
        }
      } catch (error) {
        Alert.alert('Error', 'Unable to get current location');
      }
    } else {
      Alert.alert('Permission Required', 'Location permission is needed to get your current position');
    }
  };

  const takePhoto = async () => {
    if (!cameraPermission) {
      Alert.alert('Permission Required', 'Camera permission is needed to take photos');
      return;
    }

    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0]) {
      setPhotos([...photos, result.assets[0].uri]);
    }
  };

  const pickFromGallery = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      allowsEditing: false,
      quality: 0.8,
    });

    if (!result.canceled) {
      const newPhotos = result.assets.map(asset => asset.uri);
      setPhotos([...photos, ...newPhotos]);
    }
  };

  const removePhoto = (index: number) => {
    const newPhotos = photos.filter((_, i) => i !== index);
    setPhotos(newPhotos);
  };

  const uploadImages = async (reportData: any) => {
    const uploadedImages = [];
    
    for (const photoUri of photos) {
      try {
        const fileInfo = await FileSystem.getInfoAsync(photoUri);
        if (!fileInfo.exists) continue;

        const response = await FileSystem.uploadAsync(
          'https://api.iwdg.ie/reports/upload-image',
          photoUri,
          {
            fieldName: 'image',
            httpMethod: 'POST',
            uploadType: FileSystem.FileSystemUploadType.MULTIPART,
            parameters: {
              reportId: reportData.id,
              type: 'sighting'
            }
          }
        );

        const result = JSON.parse(response.body);
        if (result.success) {
          uploadedImages.push(result.imageUrl);
        }
      } catch (error) {
        console.warn('Failed to upload image:', error);
      }
    }
    
    return uploadedImages;
  };

  const submitToBackend = async (reportData: any, imageUrls: string[]) => {
    try {
      const response = await fetch('https://api.iwdg.ie/reports/sighting', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...reportData,
          images: imageUrls,
          timestamp: new Date().toISOString()
        })
      });

      const result = await response.json();
      
      if (response.ok && result.success) {
        Alert.alert(
          'Report Submitted Successfully!', 
          'Thank you for your sighting report. IWDG has received your submission.',
          [{ text: 'OK', style: 'default' }]
        );
        
        // Reset form
        setObserver('');
        setEmail('');
        setDate('');
        setTime('');
        setLocation('');
        setCoordinates('');
        setSpecies('');
        setCount('1');
        setNotes('');
        setPhotos([]);
        
        return true;
      } else {
        throw new Error(result.message || 'Submission failed');
      }
    } catch (error) {
      console.error('Backend submission failed:', error);
      return false;
    }
  };

  const resetForm = () => {
    setObserver('');
    setEmail('');
    setDate('');
    setTime('');
    setLocation('');
    setCoordinates('');
    setSpecies('');
    setCount('1');
    setNotes('');
    setPhotos([]);
  };

  const handleSubmit = async () => {
    if (!observer || !email || !date || !location || !species) {
      Alert.alert('Missing information', 'Please fill in your name, email, date, location and species.');
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Convert images to base64 for storage
      const imageData = await Promise.all(
        photos.map(async (photoUri) => {
          const base64 = await FileSystem.readAsStringAsync(photoUri, {
            encoding: FileSystem.EncodingType.Base64
          })
          return base64
        })
      )

      if (isOnline) {
        // Try to submit directly first
        try {
          const reportData = {
            id: Date.now().toString(),
            observer,
            email,
            date,
            time,
            location,
            coordinates,
            species,
            count,
            notes,
            type: 'sighting'
          };

          const imageUrls = photos.length > 0 ? await uploadImages(reportData) : [];
          const backendSuccess = await submitToBackend(reportData, imageUrls);
          
          if (backendSuccess) {
            Alert.alert(
              'Report Submitted',
              'Thank you for your whale and dolphin sighting report. Our team will review it shortly.',
              [{ text: 'OK', onPress: resetForm }]
            );
            return;
          } else {
            throw new Error('Server error');
          }
        } catch (networkError) {
          console.log('Network submission failed, queuing for later:', networkError);
          // Fall through to offline queue
        }
      }

      // Queue for offline submission
      await queueReport('sighting', {
        location: location.trim(),
        description: `Observer: ${observer}\nEmail: ${email}\nSpecies: ${species}\nCount: ${count}\nDate: ${date}\nTime: ${time}\nCoordinates: ${coordinates}\nNotes: ${notes}`,
        images: imageData
      });

      Alert.alert(
        isOnline ? 'Queued for Retry' : 'Saved Offline', 
        isOnline 
          ? 'Your report will be sent when the connection improves.'
          : 'Your report has been saved and will be sent when you\'re back online.',
        [
          {
            text: 'OK',
            onPress: resetForm
          }
        ]
      );
    } catch (error) {
      console.error('Submit error:', error);
      Alert.alert(
        'Save Failed', 
        'Unable to save your report. Please try again.',
        [{ text: 'OK' }]
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <OfflineStatus />
      
      {!isOnline && (
        <View style={styles.offlineHeader}>
          <WifiOff size={16} color="#ef4444" />
          <Text style={styles.offlineText}>
            Offline mode - reports will be sent when connection is restored
          </Text>
        </View>
      )}

      {hasQueuedReports && <OfflineQueue />}
      
      <LinearGradient colors={["#0D4A70", "#2E86AB"]} style={styles.header}>
        <Eye color="#FFFFFF" size={36} style={styles.headerIcon} />
        <Text style={styles.headerTitle}>Report Sighting</Text>
        <Text style={styles.headerSubtitle}>Share a cetacean sighting with IWDG</Text>
      </LinearGradient>

      <View style={styles.content}>
        <View style={styles.field}>
          <Text style={styles.label}>Your name *</Text>
          <TextInput value={observer} onChangeText={setObserver} style={styles.input} placeholder="Full name" placeholderTextColor="#A3C7D6" />
        </View>

        <View style={styles.field}>
          <Text style={styles.label}>Email *</Text>
          <TextInput value={email} onChangeText={setEmail} style={styles.input} placeholder="you@example.com" keyboardType="email-address" autoCapitalize="none" placeholderTextColor="#A3C7D6" />
        </View>

        <View style={styles.row}>
          <View style={[styles.field, { flex: 1, marginRight: 8 }]}>
            <Text style={styles.label}>Date *</Text>
            <TextInput value={date} onChangeText={setDate} style={styles.input} placeholder="YYYY-MM-DD" placeholderTextColor="#A3C7D6" />
          </View>
          <View style={[styles.field, { flex: 1 }]}>
            <Text style={styles.label}>Time</Text>
            <TextInput value={time} onChangeText={setTime} style={styles.input} placeholder="HH:MM" placeholderTextColor="#A3C7D6" />
          </View>
        </View>

        <View style={styles.field}>
          <Text style={styles.label}>Location *</Text>
          <View style={styles.locationRow}>
            <TouchableOpacity onPress={getCurrentLocation} style={styles.locationButton}>
              <MapPin color="#FFFFFF" size={16} />
              <Text style={styles.locationButtonText}>Use Current Location</Text>
            </TouchableOpacity>
          </View>
          <TextInput 
            value={location} 
            onChangeText={setLocation} 
            style={[styles.input, { marginBottom: 4 }]} 
            placeholder="e.g. Mizen Head / Lat,Long" 
            placeholderTextColor="#A3C7D6" 
          />
          {coordinates && (
            <Text style={styles.coordinates}>GPS: {coordinates}</Text>
          )}
        </View>

        <View style={styles.row}>
          <View style={[styles.field, { flex: 1, marginRight: 8 }]}>
            <Text style={styles.label}>Species *</Text>
            <TextInput value={species} onChangeText={setSpecies} style={styles.input} placeholder="e.g. Minke whale" placeholderTextColor="#A3C7D6" />
          </View>
          <View style={[styles.field, { flex: 1 }]}>
            <Text style={styles.label}>Number</Text>
            <TextInput value={count} onChangeText={setCount} style={styles.input} keyboardType="numeric" placeholderTextColor="#A3C7D6" />
          </View>
        </View>

        <View style={styles.field}>
          <Text style={styles.label}>Photos</Text>
          <View style={styles.photoButtonRow}>
            <TouchableOpacity onPress={takePhoto} style={styles.cameraButton}>
              <Camera color="#FFFFFF" size={16} />
              <Text style={styles.buttonText}>Take Photo</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={pickFromGallery} style={styles.galleryButton}>
              <Text style={styles.buttonText}>Gallery</Text>
            </TouchableOpacity>
          </View>
          {photos.length > 0 && (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.photoScroll}>
              {photos.map((photo, index) => (
                <View key={index} style={styles.photoContainer}>
                  <Image source={{ uri: photo }} style={styles.photo} />
                  <TouchableOpacity onPress={() => removePhoto(index)} style={styles.removeButton}>
                    <Text style={styles.removeButtonText}>×</Text>
                  </TouchableOpacity>
                </View>
              ))}
            </ScrollView>
          )}
        </View>

        <View style={styles.field}>
          <Text style={styles.label}>Notes</Text>
          <TextInput value={notes} onChangeText={setNotes} style={[styles.input, { height: 100 }]} multiline placeholderTextColor="#A3C7D6" />
        </View>

        <TouchableOpacity 
          style={[styles.button, isSubmitting && styles.buttonDisabled]} 
          onPress={handleSubmit}
          disabled={isSubmitting}
        >
          <Text style={styles.buttonTextSubmit}>
            {isSubmitting ? 'Saving...' : 'Send Report'}
          </Text>
        </TouchableOpacity>

        <Text style={styles.helper}>Your report will open in your email app so you can review and send. If you cannot open email, send to sightings@iwdg.ie</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  offlineHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fef2f2',
    padding: 12,
    margin: 16,
    borderRadius: 8,
    borderLeftWidth: 3,
    borderLeftColor: '#ef4444',
    gap: 8
  },
  offlineText: {
    flex: 1,
    fontSize: 14,
    color: '#dc2626',
    fontWeight: '500'
  },
  container: { flex: 1, backgroundColor: '#FFFFFF' },
  header: { paddingTop: 60, paddingBottom: 30, paddingHorizontal: 20, alignItems: 'center' },
  headerIcon: { marginBottom: 12 },
  headerTitle: { fontSize: 22, fontWeight: '700', color: '#FFFFFF', marginBottom: 6 },
  headerSubtitle: { fontSize: 14, color: '#A3C7D6' },
  content: { padding: 20 },
  field: { marginBottom: 16 },
  label: { fontSize: 14, color: '#0D4A70', fontWeight: '600', marginBottom: 8 },
  input: { borderWidth: 1, borderColor: '#E8F4F8', borderRadius: 8, padding: 12, color: '#1E3A5F', backgroundColor: '#FFFFFF' },
  row: { flexDirection: 'row' },
  locationRow: { flexDirection: 'row', marginBottom: 8 },
  locationButton: { 
    backgroundColor: '#2E86AB', 
    borderRadius: 8, 
    paddingHorizontal: 16, 
    paddingVertical: 10, 
    flexDirection: 'row', 
    alignItems: 'center' 
  },
  locationButtonText: { color: '#FFFFFF', fontWeight: '600', marginLeft: 8 },
  coordinates: { fontSize: 12, color: '#666', marginTop: 4 },
  photoButtonRow: { flexDirection: 'row', marginBottom: 12 },
  cameraButton: { 
    backgroundColor: '#22C55E', 
    borderRadius: 8, 
    paddingHorizontal: 16, 
    paddingVertical: 10, 
    flexDirection: 'row', 
    alignItems: 'center',
    marginRight: 8
  },
  galleryButton: { 
    backgroundColor: '#2E86AB', 
    borderRadius: 8, 
    paddingHorizontal: 16, 
    paddingVertical: 10 
  },
  photoScroll: { marginBottom: 8 },
  photoContainer: { marginRight: 8, position: 'relative' },
  photo: { width: 80, height: 80, borderRadius: 8 },
  removeButton: { 
    position: 'absolute', 
    top: -6, 
    right: -6, 
    backgroundColor: '#EF4444', 
    borderRadius: 12, 
    width: 24, 
    height: 24, 
    alignItems: 'center', 
    justifyContent: 'center' 
  },
  removeButtonText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
  button: { backgroundColor: '#2E86AB', padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 8 },
  buttonDisabled: { backgroundColor: '#64748b' },
  buttonText: { color: '#FFFFFF', fontWeight: '600' },
  buttonTextSubmit: { color: '#FFFFFF', fontWeight: '700' },
  helper: { marginTop: 12, color: '#1E3A5F', fontSize: 13 }
});