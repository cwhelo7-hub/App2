import React from 'react';
import { View, Text, ScrollView, StyleSheet, SafeAreaView } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { LinearGradient } from 'expo-linear-gradient';
import { Waves, Calendar, Award, Users } from 'lucide-react-native';

export default function AboutScreen() {
  const yearsActive = new Date().getFullYear() - 1990;

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="light" />
      <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 40 }} showsVerticalScrollIndicator={false} accessibilityRole="scrollbar">
        {/* Hero Section */}
        <LinearGradient
          colors={["#0D4A70", "#2E86AB"]}
          style={styles.hero}
        >
          <View style={styles.heroContent}>
            <Waves color="#FFFFFF" size={52} style={styles.heroIcon} />
            <Text style={styles.heroTitle} accessibilityRole="header">Irish Whale & Dolphin Group</Text>
            <Text style={styles.heroSubtitle} accessibilityLabel={`Protecting marine life in Irish waters since 1990`}>Protecting marine life in Irish waters since 1990</Text>
          </View>
          <View style={styles.wavePattern} pointerEvents="none">
            <Text style={styles.waveEmoji} accessible={false}>🌊</Text>
          </View>
        </LinearGradient>

        {/* Main Content */}
        <View style={styles.content}>
          {/* About IWDG */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>About IWDG</Text>
            <Text style={styles.bodyText}>
              IWDG was founded in 1990 to establish an All-Ireland sighting and stranding scheme and to campaign for the declaration of Irish territorial waters as a whale and dolphin sanctuary.
            </Text>
            <Text style={styles.bodyText}>
              Since then, the group has grown to become a diverse community of people from varying backgrounds with one thing in common: a passion for whales and dolphins and the marine environment.
            </Text>
          </View>

          {/* Key Stats */}
          <View style={styles.statsContainer}>
            <View style={styles.statCard} accessibilityRole="article">
              <Calendar color="#2E86AB" size={32} />
              <Text style={styles.statNumber}>{yearsActive}</Text>
              <Text style={styles.statLabel}>Years of Conservation</Text>
            </View>
            <View style={styles.statCard} accessibilityRole="article">
              <Award color="#2E86AB" size={32} />
              <Text style={styles.statNumber}>1991</Text>
              <Text style={styles.statLabel}>Sanctuary Declared</Text>
            </View>
            <View style={styles.statCard} accessibilityRole="article">
              <Users color="#2E86AB" size={32} />
              <Text style={styles.statNumber}>All‑Island</Text>
              <Text style={styles.statLabel}>Coverage</Text>
            </View>
          </View>

          {/* Sanctuary Achievement */}
          <View style={styles.achievementCard}>
            <Text style={styles.achievementTitle}>Historic Achievement</Text>
            <Text style={styles.achievementText}>
              On June 7th, 1991, the Irish Government declared Ireland an Irish Whale and Dolphin Sanctuary - a remarkable first achievement of the newly formed group.
            </Text>
          </View>

          {/* Charity Information */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Organisation Details</Text>
            <View style={styles.infoCard}>
              <Text style={styles.infoLabel}>Status</Text>
              <Text style={styles.infoValue}>Registered Charity</Text>
            </View>
            <View style={styles.infoCard}>
              <Text style={styles.infoLabel}>Charity Number</Text>
              <Text style={styles.infoValue}>CHY11163</Text>
            </View>
            <View style={styles.infoCard}>
              <Text style={styles.infoLabel}>Regulator</Text>
              <Text style={styles.infoValue}>RCN: 20029913</Text>
            </View>
          </View>

          {/* Patron */}
          <View style={styles.patronCard}>
            <Text style={styles.patronTitle}>Our Patron</Text>
            <Text style={styles.patronName}>President Michael D. Higgins</Text>
            <Text style={styles.patronText}>
              President of Ireland Michael D. Higgins became the group's sole Patron in 2012
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#FFFFFF' },
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  hero: {
    paddingTop: 48,
    paddingBottom: 40,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  heroContent: {
    alignItems: 'center',
    zIndex: 1,
  },
  heroIcon: {
    marginBottom: 14,
  },
  heroTitle: {
    fontSize: 26,
    fontWeight: '700',
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 6,
  },
  heroSubtitle: {
    fontSize: 15,
    color: '#BFDCE6',
    textAlign: 'center',
    lineHeight: 22,
  },
  wavePattern: {
    position: 'absolute',
    bottom: -10,
    right: 20,
    opacity: 0.22,
  },
  waveEmoji: {
    fontSize: 44,
  },
  content: {
    padding: 20,
  },
  section: {
    marginBottom: 28,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#0D4A70',
    marginBottom: 12,
  },
  bodyText: {
    fontSize: 15,
    color: '#1E3A5F',
    lineHeight: 22,
    marginBottom: 12,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#E8F4F8',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginHorizontal: 6,
  },
  statNumber: {
    fontSize: 18,
    fontWeight: '700',
    color: '#0D4A70',
    marginTop: 8,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#1E3A5F',
    textAlign: 'center',
  },
  achievementCard: {
    backgroundColor: '#FFF8E7',
    padding: 16,
    borderRadius: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#FFB800',
    marginBottom: 24,
  },
  achievementTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#B8860B',
    marginBottom: 8,
  },
  achievementText: {
    fontSize: 14,
    color: '#8B7355',
    lineHeight: 20,
  },
  infoCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E8F4F8',
  },
  infoLabel: {
    fontSize: 15,
    color: '#1E3A5F',
  },
  infoValue: {
    fontSize: 15,
    fontWeight: '600',
    color: '#0D4A70',
  },
  patronCard: {
    backgroundColor: '#F0F8FF',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 24,
  },
  patronTitle: {
    fontSize: 14,
    color: '#1E3A5F',
    marginBottom: 8,
  },
  patronName: {
    fontSize: 18,
    fontWeight: '700',
    color: '#0D4A70',
    marginBottom: 10,
  },
  patronText: {
    fontSize: 14,
    color: '#1E3A5F',
    textAlign: 'center',
    lineHeight: 20,
  },
});