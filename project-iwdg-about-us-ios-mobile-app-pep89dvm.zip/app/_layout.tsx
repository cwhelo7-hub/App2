import { useEffect } from 'react';
import { Tabs } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useFrameworkReady } from '@/hooks/useFrameworkReady';
import { Waves, Users, Eye, AlertTriangle, Heart, Mail } from 'lucide-react-native';

export default function RootLayout() {
  useFrameworkReady();

  return (
    <>
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarStyle: {
            backgroundColor: '#0D4A70',
            borderTopColor: '#2E86AB',
            paddingBottom: 8,
            paddingTop: 8,
            height: 90,
          },
          tabBarLabelStyle: {
            fontSize: 11,
            fontWeight: '600',
            marginTop: 4,
          },
          tabBarActiveTintColor: '#FFFFFF',
          tabBarInactiveTintColor: '#A3C7D6',
        }}>
        <Tabs.Screen
          name="index"
          options={{
            title: 'Home',
            tabBarIcon: ({ color, size }) => (
              <Waves color={color} size={size} />
            ),
          }}
        />

        <Tabs.Screen
          name="about"
          options={{
            title: 'About',
            tabBarIcon: ({ color, size }) => (
              <Users color={color} size={size} />
            ),
          }}
        />

        <Tabs.Screen
          name="report-sighting"
          options={{
            title: 'Report sighting',
            tabBarIcon: ({ color, size }) => (
              <Eye color={color} size={size} />
            ),
          }}
        />

        <Tabs.Screen
          name="report-stranding"
          options={{
            title: 'Report stranding',
            tabBarIcon: ({ color, size }) => (
              <AlertTriangle color={color} size={size} />
            ),
          }}
        />

        <Tabs.Screen
          name="mission"
          options={{
            title: 'Mission',
            tabBarIcon: ({ color, size }) => (
              <Heart color={color} size={size} />
            ),
          }}
        />
        <Tabs.Screen
          name="contact"
          options={{
            title: 'Contact',
            tabBarIcon: ({ color, size }) => (
              <Mail color={color} size={size} />
            ),
          }}
        />
      </Tabs>
      <StatusBar style="light" backgroundColor="#0D4A70" />
    </>
  );
}