import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Clock, MapPin, Users, Award } from 'lucide-react-native';

interface TimelineEvent {
  year: string;
  title: string;
  description: string;
  icon: 'foundation' | 'sanctuary' | 'iwc' | 'patron';
}

const timelineEvents: TimelineEvent[] = [
  {
    year: '1990',
    title: 'Foundation',
    description: 'The Irish Whale and Dolphin Group was formed at a meeting in Dublin. Brendan Price called for support to declare Ireland a Whale and Dolphin Sanctuary.',
    icon: 'foundation'
  },
  {
    year: '1991',
    title: 'First Official Meeting & Sanctuary Declaration',
    description: 'The first official IWDG meeting was held in UCC. On June 7th, 1991, the Irish Government declared Ireland an Irish Whale and Dolphin Sanctuary.',
    icon: 'sanctuary'
  },
  {
    year: '1995',
    title: 'International Whaling Commission',
    description: 'Ireland hosted the International Whaling Commission (IWC) in Dublin during Michael D. Higgins tenure as Minister for Heritage. The Irish commissioner became vice chair.',
    icon: 'iwc'
  },
  {
    year: '2012',
    title: 'Presidential Patronage',
    description: 'President of Ireland, Michael D. Higgins became the group\'s sole Patron, providing prestigious support for marine conservation efforts.',
    icon: 'patron'
  }
];

const getIcon = (iconType: string) => {
  const iconProps = { size: 24, color: '#FFFFFF' };
  switch (iconType) {
    case 'foundation': return <Users {...iconProps} />;
    case 'sanctuary': return <Award {...iconProps} />;
    case 'iwc': return <MapPin {...iconProps} />;
    case 'patron': return <Clock {...iconProps} />;
    default: return <Clock {...iconProps} />;
  }
};

export default function HistoryScreen() {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <LinearGradient
        colors={['#0D4A70', '#2E86AB']}
        style={styles.header}>
        <Clock color="#FFFFFF" size={36} style={styles.headerIcon} />
        <Text style={styles.headerTitle}>Our History</Text>
        <Text style={styles.headerSubtitle}>
          Three decades of marine conservation
        </Text>
      </LinearGradient>

      <View style={styles.content}>
        {/* Introduction */}
        <View style={styles.introSection}>
          <Text style={styles.introText}>
            From a small meeting in Dublin to becoming Ireland's leading whale and dolphin conservation organization, our journey spans over three decades of dedicated marine protection efforts.
          </Text>
        </View>

        {/* Timeline */}
        <View style={styles.timelineContainer}>
          {timelineEvents.map((event, index) => (
            <View key={index} style={styles.timelineItem}>
              <View style={styles.timelineLine}>
                {index !== timelineEvents.length - 1 && (
                  <View style={styles.timelineConnector} />
                )}
              </View>
              
              <View style={styles.timelineContent}>
                <View style={styles.timelineYear}>
                  <View style={styles.timelineIcon}>
                    {getIcon(event.icon)}
                  </View>
                  <Text style={styles.yearText}>{event.year}</Text>
                </View>
                
                <View style={styles.eventCard}>
                  <Text style={styles.eventTitle}>{event.title}</Text>
                  <Text style={styles.eventDescription}>{event.description}</Text>
                </View>
              </View>
            </View>
          ))}
        </View>

        {/* Key Achievements */}
        <View style={styles.achievementsSection}>
          <Text style={styles.sectionTitle}>Key Achievements</Text>
          
          <View style={styles.achievementCard}>
            <Text style={styles.achievementEmoji}>🏆</Text>
            <View style={styles.achievementContent}>
              <Text style={styles.achievementTitle}>Ireland's First Marine Sanctuary</Text>
              <Text style={styles.achievementText}>
                Successfully campaigned for the declaration of Irish territorial waters as a whale and dolphin sanctuary in 1991.
              </Text>
            </View>
          </View>

          <View style={styles.achievementCard}>
            <Text style={styles.achievementEmoji}>🌍</Text>
            <View style={styles.achievementContent}>
              <Text style={styles.achievementTitle}>International Recognition</Text>
              <Text style={styles.achievementText}>
                Hosted the International Whaling Commission, with Irish representatives taking leadership roles.
              </Text>
            </View>
          </View>

          <View style={styles.achievementCard}>
            <Text style={styles.achievementEmoji}>🐋</Text>
            <View style={styles.achievementContent}>
              <Text style={styles.achievementTitle}>All-Ireland Coverage</Text>
              <Text style={styles.achievementText}>
                Established comprehensive sighting and stranding schemes covering all of Ireland.
              </Text>
            </View>
          </View>
        </View>

        {/* Legacy */}
        <View style={styles.legacyCard}>
          <Text style={styles.legacyTitle}>Our Continuing Legacy</Text>
          <Text style={styles.legacyText}>
            The Irish Whale and Dolphin Group continues to strive to make Ireland an effective sanctuary, building on decades of conservation success and community engagement.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 30,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  headerIcon: {
    marginBottom: 12,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#A3C7D6',
    textAlign: 'center',
  },
  content: {
    padding: 20,
  },
  introSection: {
    marginBottom: 32,
  },
  introText: {
    fontSize: 16,
    color: '#1E3A5F',
    lineHeight: 24,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  timelineContainer: {
    marginBottom: 32,
  },
  timelineItem: {
    flexDirection: 'row',
    marginBottom: 32,
  },
  timelineLine: {
    alignItems: 'center',
    marginRight: 16,
  },
  timelineConnector: {
    width: 2,
    height: 80,
    backgroundColor: '#E8F4F8',
    marginTop: 8,
  },
  timelineContent: {
    flex: 1,
  },
  timelineYear: {
    alignItems: 'center',
    marginBottom: 12,
  },
  timelineIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#2E86AB',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  yearText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0D4A70',
  },
  eventCard: {
    backgroundColor: '#E8F4F8',
    padding: 16,
    borderRadius: 12,
    marginLeft: 16,
  },
  eventTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0D4A70',
    marginBottom: 8,
  },
  eventDescription: {
    fontSize: 14,
    color: '#1E3A5F',
    lineHeight: 20,
  },
  achievementsSection: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0D4A70',
    marginBottom: 20,
    textAlign: 'center',
  },
  achievementCard: {
    flexDirection: 'row',
    backgroundColor: '#F8FFFE',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#2E86AB',
  },
  achievementEmoji: {
    fontSize: 32,
    marginRight: 16,
    marginTop: 4,
  },
  achievementContent: {
    flex: 1,
  },
  achievementTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0D4A70',
    marginBottom: 4,
  },
  achievementText: {
    fontSize: 14,
    color: '#1E3A5F',
    lineHeight: 20,
  },
  legacyCard: {
    backgroundColor: '#0D4A70',
    padding: 24,
    borderRadius: 16,
    alignItems: 'center',
  },
  legacyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 12,
    textAlign: 'center',
  },
  legacyText: {
    fontSize: 16,
    color: '#A3C7D6',
    lineHeight: 24,
    textAlign: 'center',
  },
});