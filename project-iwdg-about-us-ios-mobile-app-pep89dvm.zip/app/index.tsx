import React from 'react';
import { SafeAreaView, View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';

export default function WelcomeScreen() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="light" />

      <LinearGradient colors={["#0D4A70", "#2E86AB"]} style={styles.hero}>
        <View style={styles.heroInner}>
          <Text style={styles.title}>Irish Whale & Dolphin Group</Text>
          <Text style={styles.subtitle}>Protecting whales and dolphins in Irish waters</Text>

          <TouchableOpacity style={styles.cta} onPress={() => router.push('/about')} accessibilityRole="button">
            <Text style={styles.ctaText}>Explore About IWDG</Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>

      <View style={styles.content}>
        <Text style={styles.lead}>Discover our mission, history and team. Use the tabs below to report sightings, access mission details, or contact us.</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#FFFFFF' },
  hero: {
    paddingTop: 72,
    paddingBottom: 56,
    paddingHorizontal: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  heroInner: { alignItems: 'center' },
  title: {
    color: '#FFFFFF',
    fontSize: 28,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    color: '#BFDCE6',
    fontSize: 15,
    textAlign: 'center',
    marginBottom: 18,
  },
  cta: {
    backgroundColor: '#FFFFFF',
    paddingVertical: 12,
    paddingHorizontal: 22,
    borderRadius: 999,
  },
  ctaText: {
    color: '#0D4A70',
    fontWeight: '700',
    fontSize: 16,
  },
  content: {
    padding: 20,
  },
  lead: { color: '#1E3A5F', fontSize: 15, lineHeight: 22 },
});