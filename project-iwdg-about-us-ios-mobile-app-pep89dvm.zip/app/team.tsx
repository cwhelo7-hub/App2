import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Linking } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Users, Mail, Phone, Star, Crown, User } from 'lucide-react-native';

interface TeamMember {
  name: string;
  role: string;
  email: string;
  phone?: string;
  type: 'director' | 'officer';
}

const directors: TeamMember[] = [
  { name: 'Dr Patrick Hartigan', role: 'Chair', email: 'hartigan@moher.ie', type: 'director' },
  { name: 'Jane Meehan', role: 'Director', email: 'jane.meehan@iwdg.ie', type: 'director' },
  { name: 'Dr Noirin Burke', role: 'Director', email: 'noirin.burke@iwdg.ie', type: 'director' },
  { name: 'Ben Doyle', role: 'Director', email: 'ben.doyle@iwdg.ie', type: 'director' },
  { name: 'Amado Hidalgo', role: 'Director', email: 'amado@iwdg.ie', type: 'director' },
  { name: 'Eamonn Clarke', role: 'Secretary', email: 'eamonnfclarke@gmail.com', type: 'director' },
];

const officers: TeamMember[] = [
  { name: 'Dr Simon Berrow', role: 'Chief Executive Officer', email: 'ceo@iwdg.ie', phone: '+353 86 8545450', type: 'officer' },
  { name: 'Dr Stephen Comerford', role: 'ORE & Marine Biodiversity Officer', email: 'policy@iwdg.ie', type: 'officer' },
  { name: 'Csilla Trungel', role: 'Coordination and Communications Officer', email: 'csilla.trungel@iwdg.ie', type: 'officer' },
  { name: 'Trea Heapes', role: 'IT Admin', email: 'coordinator@iwdg.ie', phone: '+353 86 3819 216', type: 'officer' },
  { name: 'Gemma O\'Connor', role: 'Live Stranding Network Response Coordinator', email: 'gemma.oconnor@iwdg.ie', phone: '+353 97 28118', type: 'officer' },
  { name: 'Jack O\'Callaghan', role: 'Science Officer', email: 'science@iwdg.ie', type: 'officer' },
  { name: 'Pádraig Whooley', role: 'Sightings Officer', email: 'sightings@iwdg.ie', phone: '+353 86 3850568', type: 'officer' },
  { name: 'Stephanie Levesque', role: 'Strandings Officer', email: 'strandings@iwdg.ie', type: 'officer' },
  { name: 'Sloan Massie', role: 'Welfare Officer', email: 'welfare@iwdg.ie', phone: '083 181 4434', type: 'officer' },
  { name: 'Frances Bermingham', role: 'Membership Officer', email: 'membership@iwdg.ie', type: 'officer' },
  { name: 'Mags Daly', role: 'Shannon Dolphin Project Officer', email: 'mags.daly@iwdg.ie', phone: '+353 83 8401102', type: 'officer' },
  { name: 'Andrew Shine', role: 'Celtic Mist Officer', email: 'celticmist@iwdg.ie', phone: '0863329983', type: 'officer' },
  { name: 'Dave Wall', role: 'Conservation Officer', email: 'conservation@iwdg.ie', phone: '+44 77 71762355', type: 'officer' },
  { name: 'Rachele Kempston', role: 'Northern Ireland Officer', email: 'northernireland@iwdg.ie', type: 'officer' },
  { name: 'Eva Lambert', role: 'Marine Policy and Advocacy Officer', email: 'eva.lambert@iwdg.ie', type: 'officer' },
  { name: 'Cian Ó Nialáin', role: 'Outreach Officer', email: 'outreach@iwdg.ie', type: 'officer' },
  { name: 'Susanne Matejka', role: 'Book Keeper', email: 'accounts@iwdg.ie', type: 'officer' },
];

const handleEmailPress = (email: string) => {
  Linking.openURL(`mailto:${email}`);
};

const handlePhonePress = (phone: string) => {
  Linking.openURL(`tel:${phone}`);
};

const TeamMemberCard = ({ member }: { member: TeamMember }) => (
  <View style={[
    styles.memberCard,
    member.type === 'director' ? styles.directorCard : styles.officerCard
  ]}>
    <View style={styles.memberHeader}>
      <View style={[
        styles.memberIcon,
        member.type === 'director' ? styles.directorIcon : styles.officerIcon
      ]}>
        {member.type === 'director' ? (
          <Crown color="#FFFFFF" size={20} />
        ) : (
          <User color="#FFFFFF" size={20} />
        )}
      </View>
      <View style={styles.memberInfo}>
        <Text style={styles.memberName}>{member.name}</Text>
        <Text style={styles.memberRole}>{member.role}</Text>
      </View>
    </View>
    
    <View style={styles.contactInfo}>
      <TouchableOpacity 
        style={styles.contactButton}
        onPress={() => handleEmailPress(member.email)}
      >
        <Mail color="#2E86AB" size={16} />
        <Text style={styles.contactText}>{member.email}</Text>
      </TouchableOpacity>
      
      {member.phone && (
        <TouchableOpacity 
          style={styles.contactButton}
          onPress={() => handlePhonePress(member.phone!)}
        >
          <Phone color="#2E86AB" size={16} />
          <Text style={styles.contactText}>{member.phone}</Text>
        </TouchableOpacity>
      )}
    </View>
  </View>
);

export default function TeamScreen() {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <LinearGradient
        colors={['#0D4A70', '#2E86AB']}
        style={styles.header}>
        <Users color="#FFFFFF" size={36} style={styles.headerIcon} />
        <Text style={styles.headerTitle}>Our Team</Text>
        <Text style={styles.headerSubtitle}>
          Dedicated marine conservation professionals
        </Text>
      </LinearGradient>

      <View style={styles.content}>
        {/* Team Overview */}
        <View style={styles.overviewSection}>
          <Text style={styles.overviewText}>
            Our diverse team brings together marine biologists, conservationists, researchers, and administrators united by a shared passion for protecting whales, dolphins, and Irish marine environments.
          </Text>
        </View>

        {/* Directors Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Crown color="#0D4A70" size={24} />
            <Text style={styles.sectionTitle}>Board of Directors</Text>
          </View>
          <Text style={styles.sectionDescription}>
            The Board of Directors ensures IWDG complies with legal obligations and provides strategic direction for our conservation mission.
          </Text>
          
          {directors.map((director, index) => (
            <TeamMemberCard key={index} member={director} />
          ))}
        </View>

        {/* Officers Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Star color="#0D4A70" size={24} />
            <Text style={styles.sectionTitle}>IWDG Officers</Text>
          </View>
          <Text style={styles.sectionDescription}>
            Officers handle day-to-day operations, research projects, conservation initiatives, and run our vessel Celtic Mist along with sightings and stranding schemes.
          </Text>
          
          {officers.map((officer, index) => (
            <TeamMemberCard key={index} member={officer} />
          ))}
        </View>

        {/* Join Our Team */}
        <View style={styles.joinTeamCard}>
          <Text style={styles.joinTeamEmoji}>🌊</Text>
          <Text style={styles.joinTeamTitle}>Join Our Mission</Text>
          <Text style={styles.joinTeamText}>
            Interested in taking on an officer role within IWDG? We welcome passionate individuals who share our commitment to marine conservation.
          </Text>
          <TouchableOpacity 
            style={styles.contactButton}
            onPress={() => handleEmailPress('ceo@iwdg.ie')}
          >
            <Mail color="#0D4A70" size={16} />
            <Text style={[styles.contactText, { color: '#0D4A70' }]}>Contact CEO</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 30,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  headerIcon: {
    marginBottom: 12,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#A3C7D6',
    textAlign: 'center',
  },
  content: {
    padding: 20,
  },
  overviewSection: {
    marginBottom: 32,
  },
  overviewText: {
    fontSize: 16,
    color: '#1E3A5F',
    lineHeight: 24,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  section: {
    marginBottom: 32,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0D4A70',
    marginLeft: 12,
  },
  sectionDescription: {
    fontSize: 14,
    color: '#1E3A5F',
    lineHeight: 20,
    marginBottom: 20,
  },
  memberCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  directorCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#FFB800',
  },
  officerCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#2E86AB',
  },
  memberHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  memberIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  directorIcon: {
    backgroundColor: '#FFB800',
  },
  officerIcon: {
    backgroundColor: '#2E86AB',
  },
  memberInfo: {
    flex: 1,
  },
  memberName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0D4A70',
    marginBottom: 4,
  },
  memberRole: {
    fontSize: 14,
    color: '#1E3A5F',
    lineHeight: 18,
  },
  contactInfo: {
    borderTopWidth: 1,
    borderTopColor: '#E8F4F8',
    paddingTop: 12,
  },
  contactButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  contactText: {
    fontSize: 14,
    color: '#2E86AB',
    marginLeft: 8,
    textDecorationLine: 'underline',
  },
  joinTeamCard: {
    backgroundColor: '#E8F4F8',
    padding: 24,
    borderRadius: 16,
    alignItems: 'center',
    marginBottom: 20,
  },
  joinTeamEmoji: {
    fontSize: 48,
    marginBottom: 16,
  },
  joinTeamTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0D4A70',
    marginBottom: 12,
  },
  joinTeamText: {
    fontSize: 16,
    color: '#1E3A5F',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 20,
  },
});