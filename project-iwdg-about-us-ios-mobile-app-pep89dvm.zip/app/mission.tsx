import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Heart, Target, Eye, Compass, Shield, BookOpen, Globe, Users } from 'lucide-react-native';

const missionPoints = [
  {
    icon: 'research',
    title: 'Research Excellence',
    description: 'Conducting cutting-edge research on cetaceans and their habitats through collaboration with universities and research institutions.',
  },
  {
    icon: 'conservation',
    title: 'Conservation Action',
    description: 'Actively protecting whales, dolphins, and porpoises through habitat conservation and policy advocacy.',
  },
  {
    icon: 'education',
    title: 'Public Education',
    description: 'Promoting better understanding of marine mammals through educational programs and community outreach.',
  },
  {
    icon: 'collaboration',
    title: 'Collaborative Networks',
    description: 'Working with government agencies, research groups, and international organizations to achieve conservation goals.',
  },
];

const achievements = [
  {
    emoji: '🏆',
    title: 'Ireland\'s First Whale & Dolphin Sanctuary',
    description: 'Successfully campaigned for the declaration of Irish territorial waters as a marine mammal sanctuary in 1991.',
  },
  {
    emoji: '🔬',
    title: 'Comprehensive Monitoring Programs',
    description: 'Established All-Ireland sighting and stranding schemes that provide crucial data for conservation efforts.',
  },
  {
    emoji: '🌍',
    title: 'International Leadership',
    description: 'Hosted the International Whaling Commission and provided leadership in global marine conservation initiatives.',
  },
  {
    emoji: '📚',
    title: 'Scientific Contributions',
    description: 'Published extensive research contributing to global understanding of cetacean behavior and conservation needs.',
  },
];

const getIcon = (iconType: string) => {
  const iconProps = { size: 32, color: '#2E86AB' };
  switch (iconType) {
    case 'research': return <Target {...iconProps} />;
    case 'conservation': return <Shield {...iconProps} />;
    case 'education': return <BookOpen {...iconProps} />;
    case 'collaboration': return <Users {...iconProps} />;
    default: return <Heart {...iconProps} />;
  }
};

export default function MissionScreen() {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <LinearGradient
        colors={['#0D4A70', '#2E86AB']}
        style={styles.header}>
        <Heart color="#FFFFFF" size={36} style={styles.headerIcon} />
        <Text style={styles.headerTitle}>Our Mission</Text>
        <Text style={styles.headerSubtitle}>
          Protecting marine life through science and conservation
        </Text>
      </LinearGradient>

      <View style={styles.content}>
        {/* Mission Statement */}
        <View style={styles.missionStatement}>
          <View style={styles.missionHeader}>
            <Compass color="#0D4A70" size={28} />
            <Text style={styles.missionTitle}>Our Mission Statement</Text>
          </View>
          <Text style={styles.missionText}>
            To promote better understanding of cetaceans & their habitats through education & research.
          </Text>
          <View style={styles.missionSubtext}>
            <Text style={styles.subtext}>We carry this out through:</Text>
            <Text style={styles.subtextItem}>• Collection & distribution of information</Text>
            <Text style={styles.subtextItem}>• Collaboration with universities & government</Text>
            <Text style={styles.subtextItem}>• Partnership with research groups</Text>
          </View>
        </View>

        {/* Vision */}
        <View style={styles.visionCard}>
          <Eye color="#FFFFFF" size={24} style={styles.visionIcon} />
          <Text style={styles.visionTitle}>Our Vision</Text>
          <Text style={styles.visionText}>
            To ensure Ireland remains an effective sanctuary for whales, dolphins, and porpoises, where these magnificent creatures can thrive in protected waters for generations to come.
          </Text>
        </View>

        {/* Mission Points */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>How We Achieve Our Mission</Text>
          
          {missionPoints.map((point, index) => (
            <View key={index} style={styles.missionCard}>
              <View style={styles.missionIcon}>
                {getIcon(point.icon)}
              </View>
              <View style={styles.missionContent}>
                <Text style={styles.missionCardTitle}>{point.title}</Text>
                <Text style={styles.missionCardDescription}>{point.description}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Key Achievements */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Our Impact</Text>
          
          {achievements.map((achievement, index) => (
            <View key={index} style={styles.achievementCard}>
              <Text style={styles.achievementEmoji}>{achievement.emoji}</Text>
              <View style={styles.achievementContent}>
                <Text style={styles.achievementTitle}>{achievement.title}</Text>
                <Text style={styles.achievementDescription}>{achievement.description}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Whale Tales */}
        <View style={styles.whaleTimesStealsCard}>
          <Text style={styles.whaleTalesEmoji}>🐋</Text>
          <Text style={styles.whaleTalesTitle}>Whale Tales</Text>
          <Text style={styles.whaleTalesSubtitle}>Our Biennial Gathering</Text>
          <Text style={styles.whaleTalesDescription}>
            Whale Tales is our biennial gathering where members and people interested in whales, dolphins, and porpoises are invited to join us in shared appreciation and admiration of these charismatic animals.
          </Text>
        </View>

        {/* Global Impact */}
        <View style={styles.globalCard}>
          <Globe color="#FFFFFF" size={28} style={styles.globalIcon} />
          <Text style={styles.globalTitle}>Global Conservation Leadership</Text>
          <Text style={styles.globalText}>
            As Ireland's leading whale and dolphin conservation organization, we contribute to international research, policy development, and conservation efforts that protect marine mammals worldwide.
          </Text>
        </View>

        {/* Call to Action */}
        <View style={styles.ctaCard}>
          <Text style={styles.ctaTitle}>Join Our Conservation Mission</Text>
          <Text style={styles.ctaText}>
            Every contribution helps us continue our vital work protecting Ireland's marine mammals and their ocean home.
          </Text>
          <View style={styles.ctaButtons}>
            <View style={styles.ctaButton}>
              <Text style={styles.ctaButtonText}>Become a Member</Text>
            </View>
            <View style={styles.ctaButton}>
              <Text style={styles.ctaButtonText}>Report Sightings</Text>
            </View>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 30,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  headerIcon: {
    marginBottom: 12,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#A3C7D6',
    textAlign: 'center',
  },
  content: {
    padding: 20,
  },
  missionStatement: {
    backgroundColor: '#E8F4F8',
    padding: 24,
    borderRadius: 16,
    marginBottom: 24,
  },
  missionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  missionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0D4A70',
    marginLeft: 12,
  },
  missionText: {
    fontSize: 18,
    color: '#0D4A70',
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 26,
  },
  missionSubtext: {
    borderTopWidth: 1,
    borderTopColor: '#A3C7D6',
    paddingTop: 16,
  },
  subtext: {
    fontSize: 16,
    color: '#1E3A5F',
    fontWeight: '600',
    marginBottom: 8,
  },
  subtextItem: {
    fontSize: 14,
    color: '#1E3A5F',
    marginBottom: 4,
    marginLeft: 8,
  },
  visionCard: {
    backgroundColor: '#0D4A70',
    padding: 24,
    borderRadius: 16,
    alignItems: 'center',
    marginBottom: 32,
  },
  visionIcon: {
    marginBottom: 12,
  },
  visionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 12,
  },
  visionText: {
    fontSize: 16,
    color: '#A3C7D6',
    textAlign: 'center',
    lineHeight: 24,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0D4A70',
    marginBottom: 20,
    textAlign: 'center',
  },
  missionCard: {
    flexDirection: 'row',
    backgroundColor: '#F8FFFE',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#2E86AB',
  },
  missionIcon: {
    marginRight: 16,
    marginTop: 4,
  },
  missionContent: {
    flex: 1,
  },
  missionCardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0D4A70',
    marginBottom: 8,
  },
  missionCardDescription: {
    fontSize: 14,
    color: '#1E3A5F',
    lineHeight: 20,
  },
  achievementCard: {
    flexDirection: 'row',
    backgroundColor: '#FFFBF0',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#FFB800',
  },
  achievementEmoji: {
    fontSize: 28,
    marginRight: 16,
    marginTop: 4,
  },
  achievementContent: {
    flex: 1,
  },
  achievementTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0D4A70',
    marginBottom: 4,
  },
  achievementDescription: {
    fontSize: 14,
    color: '#1E3A5F',
    lineHeight: 20,
  },
  whaleTimesStealsCard: {
    backgroundColor: '#F0F8FF',
    padding: 24,
    borderRadius: 16,
    alignItems: 'center',
    marginBottom: 24,
  },
  whaleTalesEmoji: {
    fontSize: 48,
    marginBottom: 16,
  },
  whaleTalesTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0D4A70',
    marginBottom: 4,
  },
  whaleTalesSubtitle: {
    fontSize: 16,
    color: '#2E86AB',
    marginBottom: 16,
  },
  whaleTalesDescription: {
    fontSize: 14,
    color: '#1E3A5F',
    textAlign: 'center',
    lineHeight: 20,
  },
  globalCard: {
    backgroundColor: '#2E86AB',
    padding: 24,
    borderRadius: 16,
    alignItems: 'center',
    marginBottom: 24,
  },
  globalIcon: {
    marginBottom: 12,
  },
  globalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 12,
    textAlign: 'center',
  },
  globalText: {
    fontSize: 14,
    color: '#E8F4F8',
    textAlign: 'center',
    lineHeight: 20,
  },
  ctaCard: {
    backgroundColor: '#E8F4F8',
    padding: 24,
    borderRadius: 16,
    alignItems: 'center',
  },
  ctaTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0D4A70',
    marginBottom: 12,
    textAlign: 'center',
  },
  ctaText: {
    fontSize: 16,
    color: '#1E3A5F',
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 24,
  },
  ctaButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  ctaButton: {
    backgroundColor: '#2E86AB',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 25,
    flex: 0.48,
  },
  ctaButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
});