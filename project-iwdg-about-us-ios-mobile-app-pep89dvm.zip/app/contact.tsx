import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Linking, TextInput } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Mail, Phone, MapPin, Clock, Send, Globe, MessageCircle } from 'lucide-react-native';
import { useState } from 'react';

const contactMethods = [
  {
    icon: 'phone',
    title: 'Phone',
    value: '(065) 905 1763',
    subtitle: 'Office hours: 9am - 5pm',
    action: 'tel:+35365905176',
  },
  {
    icon: 'email',
    title: 'General Enquiries',
    value: 'info@iwdg.ie',
    subtitle: 'We respond within 24 hours',
    action: 'mailto:info@iwdg.ie',
  },
  {
    icon: 'location',
    title: 'Visit Us',
    value: 'Merchants Quay, Kilrush',
    subtitle: 'Co. Clare, Ireland V15 E762',
    action: null,
  },
];

const specialistContacts = [
  { role: 'CEO', email: 'ceo@iwdg.ie', phone: '+353 86 8545450' },
  { role: 'Sightings', email: 'sightings@iwdg.ie', phone: '+353 86 3850568' },
  { role: 'Strandings', email: 'strandings@iwdg.ie', phone: null },
  { role: 'Science', email: 'science@iwdg.ie', phone: null },
  { role: 'Membership', email: 'membership@iwdg.ie', phone: null },
  { role: 'Conservation', email: 'conservation@iwdg.ie', phone: '+44 77 71762355' },
];

const getContactIcon = (iconType: string) => {
  const iconProps = { size: 24, color: '#2E86AB' };
  switch (iconType) {
    case 'phone': return <Phone {...iconProps} />;
    case 'email': return <Mail {...iconProps} />;
    case 'location': return <MapPin {...iconProps} />;
    default: return <Mail {...iconProps} />;
  }
};

export default function ContactScreen() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const handleContact = (action: string | null) => {
    if (action) {
      Linking.openURL(action);
    }
  };

  const handleSendMessage = () => {
    const subject = `Message from ${name} via IWDG App`;
    const body = `Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`;
    Linking.openURL(`mailto:info@iwdg.ie?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`);
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <LinearGradient
        colors={['#0D4A70', '#2E86AB']}
        style={styles.header}>
        <Mail color="#FFFFFF" size={36} style={styles.headerIcon} />
        <Text style={styles.headerTitle}>Contact Us</Text>
        <Text style={styles.headerSubtitle}>
          Get in touch with our marine conservation team
        </Text>
      </LinearGradient>

      <View style={styles.content}>
        {/* Quick Contact Methods */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Get In Touch</Text>
          
          {contactMethods.map((method, index) => (
            <TouchableOpacity
              key={index}
              style={styles.contactCard}
              onPress={() => handleContact(method.action)}
              disabled={!method.action}
            >
              <View style={styles.contactIcon}>
                {getContactIcon(method.icon)}
              </View>
              <View style={styles.contactContent}>
                <Text style={styles.contactTitle}>{method.title}</Text>
                <Text style={styles.contactValue}>{method.value}</Text>
                <Text style={styles.contactSubtitle}>{method.subtitle}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        {/* Specialist Contacts */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Specialist Contacts</Text>
          <Text style={styles.sectionDescription}>
            Contact our specialists directly for specific enquiries
          </Text>
          
          {specialistContacts.map((contact, index) => (
            <View key={index} style={styles.specialistCard}>
              <Text style={styles.specialistRole}>{contact.role}</Text>
              <View style={styles.specialistContacts}>
                <TouchableOpacity
                  style={styles.specialistButton}
                  onPress={() => Linking.openURL(`mailto:${contact.email}`)}
                >
                  <Mail color="#2E86AB" size={16} />
                  <Text style={styles.specialistButtonText}>{contact.email}</Text>
                </TouchableOpacity>
                {contact.phone && (
                  <TouchableOpacity
                    style={styles.specialistButton}
                    onPress={() => Linking.openURL(`tel:${contact.phone}`)}
                  >
                    <Phone color="#2E86AB" size={16} />
                    <Text style={styles.specialistButtonText}>{contact.phone}</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          ))}
        </View>

        {/* Contact Form */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Send Us a Message</Text>
          <Text style={styles.sectionDescription}>
            We'd love to hear from you. Send us a message and we'll respond as soon as possible.
          </Text>
          
          <View style={styles.form}>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Name *</Text>
              <TextInput
                style={styles.textInput}
                value={name}
                onChangeText={setName}
                placeholder="Your full name"
                placeholderTextColor="#A3C7D6"
              />
            </View>
            
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Email *</Text>
              <TextInput
                style={styles.textInput}
                value={email}
                onChangeText={setEmail}
                placeholder="your.email@example.com"
                keyboardType="email-address"
                autoCapitalize="none"
                placeholderTextColor="#A3C7D6"
              />
            </View>
            
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Message *</Text>
              <TextInput
                style={[styles.textInput, styles.messageInput]}
                value={message}
                onChangeText={setMessage}
                placeholder="Tell us about your enquiry..."
                multiline
                numberOfLines={4}
                textAlignVertical="top"
                placeholderTextColor="#A3C7D6"
              />
            </View>
            
            <TouchableOpacity
              style={[styles.sendButton, (!name || !email || !message) && styles.sendButtonDisabled]}
              onPress={handleSendMessage}
              disabled={!name || !email || !message}
            >
              <Send color="#FFFFFF" size={16} />
              <Text style={styles.sendButtonText}>Send Message</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Office Hours */}
        <View style={styles.officeHoursCard}>
          <Clock color="#0D4A70" size={24} />
          <Text style={styles.officeHoursTitle}>Office Hours</Text>
          <Text style={styles.officeHoursText}>Monday - Friday: 9:00 AM - 5:00 PM</Text>
          <Text style={styles.officeHoursText}>Weekend: Emergency marine mammal responses only</Text>
        </View>

        {/* Location Card */}
        <View style={styles.locationCard}>
          <MapPin color="#FFFFFF" size={28} style={styles.locationIcon} />
          <Text style={styles.locationTitle}>Shannon Dolphin Research Centre</Text>
          <Text style={styles.locationAddress}>Merchants Quay</Text>
          <Text style={styles.locationAddress}>Kilrush, Co. Clare</Text>
          <Text style={styles.locationAddress}>Ireland V15 E762</Text>
        </View>

        {/* Social Links */}
        <View style={styles.socialCard}>
          <Text style={styles.socialTitle}>Follow Our Work</Text>
          <Text style={styles.socialDescription}>
            Stay updated with our latest conservation efforts and marine research
          </Text>
          <View style={styles.socialButtons}>
            <TouchableOpacity style={styles.socialButton}>
              <Globe color="#0D4A70" size={20} />
              <Text style={styles.socialButtonText}>iwdg.ie</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.socialButton}>
              <MessageCircle color="#0D4A70" size={20} />
              <Text style={styles.socialButtonText}>Newsletter</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 30,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  headerIcon: {
    marginBottom: 12,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#A3C7D6',
    textAlign: 'center',
  },
  content: {
    padding: 20,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0D4A70',
    marginBottom: 12,
  },
  sectionDescription: {
    fontSize: 14,
    color: '#1E3A5F',
    marginBottom: 20,
    lineHeight: 20,
  },
  contactCard: {
    flexDirection: 'row',
    backgroundColor: '#F8FFFE',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#2E86AB',
  },
  contactIcon: {
    marginRight: 16,
    marginTop: 4,
  },
  contactContent: {
    flex: 1,
  },
  contactTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0D4A70',
    marginBottom: 4,
  },
  contactValue: {
    fontSize: 16,
    color: '#1E3A5F',
    marginBottom: 2,
  },
  contactSubtitle: {
    fontSize: 12,
    color: '#2E86AB',
  },
  specialistCard: {
    backgroundColor: '#E8F4F8',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  specialistRole: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0D4A70',
    marginBottom: 12,
  },
  specialistContacts: {
    gap: 8,
  },
  specialistButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
  },
  specialistButtonText: {
    fontSize: 14,
    color: '#2E86AB',
    marginLeft: 8,
    textDecorationLine: 'underline',
  },
  form: {
    backgroundColor: '#F8FFFE',
    padding: 20,
    borderRadius: 16,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0D4A70',
    marginBottom: 8,
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#E8F4F8',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: '#1E3A5F',
    backgroundColor: '#FFFFFF',
  },
  messageInput: {
    height: 100,
    textAlignVertical: 'top',
  },
  sendButton: {
    backgroundColor: '#2E86AB',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    borderRadius: 8,
    marginTop: 8,
  },
  sendButtonDisabled: {
    backgroundColor: '#A3C7D6',
  },
  sendButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  officeHoursCard: {
    backgroundColor: '#E8F4F8',
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
    marginBottom: 20,
  },
  officeHoursTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0D4A70',
    marginVertical: 12,
  },
  officeHoursText: {
    fontSize: 14,
    color: '#1E3A5F',
    textAlign: 'center',
    marginBottom: 4,
  },
  locationCard: {
    backgroundColor: '#0D4A70',
    padding: 24,
    borderRadius: 16,
    alignItems: 'center',
    marginBottom: 20,
  },
  locationIcon: {
    marginBottom: 12,
  },
  locationTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 12,
  },
  locationAddress: {
    fontSize: 14,
    color: '#A3C7D6',
    textAlign: 'center',
    marginBottom: 2,
  },
  socialCard: {
    backgroundColor: '#F0F8FF',
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
  },
  socialTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0D4A70',
    marginBottom: 8,
  },
  socialDescription: {
    fontSize: 14,
    color: '#1E3A5F',
    textAlign: 'center',
    marginBottom: 16,
    lineHeight: 20,
  },
  socialButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  socialButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#0D4A70',
  },
  socialButtonText: {
    fontSize: 14,
    color: '#0D4A70',
    marginLeft: 6,
    fontWeight: '600',
  },
});