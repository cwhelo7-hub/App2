import React from 'react'
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native'
import { RefreshCw, WifiOff, AlertCircle, CheckCircle, X } from 'lucide-react-native'
import { useOfflineReports } from '../hooks/useOfflineReports'

interface OfflineQueueProps {
  visible?: boolean
}

export const OfflineQueue: React.FC<OfflineQueueProps> = ({ visible = true }) => {
  const { 
    queuedReports, 
    isOnline, 
    isSyncing, 
    syncQueuedReports, 
    removeFromQueue,
    clearFailedReports,
    failedReports
  } = useOfflineReports()

  if (!visible || queuedReports.length === 0) {
    return null
  }

  const pendingReports = queuedReports.filter(r => r.attempts < 3)
  const hasFailedReports = failedReports.length > 0

  const handleRetryAll = () => {
    if (isOnline) {
      syncQueuedReports()
    } else {
      Alert.alert('No Connection', 'Please check your internet connection and try again.')
    }
  }

  const handleClearFailed = () => {
    Alert.alert(
      'Clear Failed Reports',
      'Are you sure you want to remove all failed reports? This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Clear', style: 'destructive', onPress: clearFailedReports }
      ]
    )
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-IE', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.statusRow}>
          {!isOnline && <WifiOff size={16} color="#ef4444" />}
          <Text style={styles.title}>
            Queued Reports ({queuedReports.length})
          </Text>
          {isSyncing && (
            <RefreshCw size={16} color="#2563eb" style={styles.spinningIcon} />
          )}
        </View>
        
        <View style={styles.actions}>
          {hasFailedReports && (
            <TouchableOpacity onPress={handleClearFailed} style={styles.clearButton}>
              <X size={14} color="#ef4444" />
              <Text style={styles.clearText}>Clear Failed</Text>
            </TouchableOpacity>
          )}
          
          <TouchableOpacity 
            onPress={handleRetryAll} 
            style={[styles.retryButton, (!isOnline || isSyncing) && styles.disabledButton]}
            disabled={!isOnline || isSyncing}
          >
            <RefreshCw size={14} color={isOnline ? "#ffffff" : "#94a3b8"} />
            <Text style={[styles.retryText, (!isOnline || isSyncing) && styles.disabledText]}>
              {isSyncing ? 'Syncing...' : 'Retry All'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.reportsList}>
        {queuedReports.map((report) => {
          const isFailed = report.attempts >= 3
          const isPending = report.attempts < 3
          
          return (
            <View key={report.id} style={[styles.reportItem, isFailed && styles.failedItem]}>
              <View style={styles.reportInfo}>
                <View style={styles.reportHeader}>
                  <Text style={styles.reportType}>
                    {report.type === 'sighting' ? '🐋 Sighting' : '⚠️ Stranding'}
                  </Text>
                  <Text style={styles.reportDate}>
                    {formatDate(report.createdAt)}
                  </Text>
                </View>
                
                <Text style={styles.reportLocation} numberOfLines={1}>
                  📍 {report.data.location}
                </Text>
                
                <View style={styles.statusRow}>
                  {isFailed ? (
                    <>
                      <AlertCircle size={14} color="#ef4444" />
                      <Text style={styles.failedText}>Failed after {report.attempts} attempts</Text>
                    </>
                  ) : isPending ? (
                    <>
                      <RefreshCw size={14} color="#f59e0b" />
                      <Text style={styles.pendingText}>
                        {report.attempts === 0 ? 'Pending' : `Retry ${report.attempts}/3`}
                      </Text>
                    </>
                  ) : (
                    <>
                      <CheckCircle size={14} color="#10b981" />
                      <Text style={styles.successText}>Sent</Text>
                    </>
                  )}
                </View>
              </View>
              
              {isFailed && (
                <TouchableOpacity 
                  onPress={() => removeFromQueue(report.id)}
                  style={styles.removeButton}
                >
                  <X size={16} color="#ef4444" />
                </TouchableOpacity>
              )}
            </View>
          )
        })}
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    padding: 16,
    margin: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b'
  },
  spinningIcon: {
    transform: [{ rotate: '45deg' }]
  },
  actions: {
    flexDirection: 'row',
    gap: 8
  },
  retryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2563eb',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
    gap: 4
  },
  retryText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '500'
  },
  disabledButton: {
    backgroundColor: '#e2e8f0'
  },
  disabledText: {
    color: '#94a3b8'
  },
  clearButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 6,
    gap: 4
  },
  clearText: {
    color: '#ef4444',
    fontSize: 12,
    fontWeight: '500'
  },
  reportsList: {
    gap: 8
  },
  reportItem: {
    backgroundColor: '#ffffff',
    padding: 12,
    borderRadius: 8,
    borderLeftWidth: 3,
    borderLeftColor: '#f59e0b',
    flexDirection: 'row',
    alignItems: 'center'
  },
  failedItem: {
    borderLeftColor: '#ef4444',
    backgroundColor: '#fef2f2'
  },
  reportInfo: {
    flex: 1
  },
  reportHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4
  },
  reportType: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1e293b'
  },
  reportDate: {
    fontSize: 12,
    color: '#64748b'
  },
  reportLocation: {
    fontSize: 12,
    color: '#64748b',
    marginBottom: 6
  },
  pendingText: {
    fontSize: 12,
    color: '#f59e0b',
    marginLeft: 4
  },
  failedText: {
    fontSize: 12,
    color: '#ef4444',
    marginLeft: 4
  },
  successText: {
    fontSize: 12,
    color: '#10b981',
    marginLeft: 4
  },
  removeButton: {
    padding: 4,
    marginLeft: 8
  }
})