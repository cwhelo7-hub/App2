import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Wifi, WifiOff, RefreshCw, Clock } from 'lucide-react-native';
import { useOfflineStorage } from '../hooks/useOfflineStorage';

export const OfflineStatus = () => {
  const { isOnline, pendingReports, isSyncing, syncPendingReports } = useOfflineStorage();

  if (isOnline && pendingReports.length === 0) {
    return null; // Hide when online with no pending reports
  }

  return (
    <View style={styles.container}>
      <View style={styles.statusRow}>
        {isOnline ? (
          <Wifi size={16} color="#22c55e" />
        ) : (
          <WifiOff size={16} color="#ef4444" />
        )}
        
        <Text style={[styles.statusText, { color: isOnline ? '#22c55e' : '#ef4444' }]}>
          {isOnline ? 'Online' : 'Offline'}
        </Text>

        {pendingReports.length > 0 && (
          <>
            <View style={styles.separator} />
            <Clock size={16} color="#f59e0b" />
            <Text style={styles.pendingText}>
              {pendingReports.length} pending report{pendingReports.length !== 1 ? 's' : ''}
            </Text>
          </>
        )}
      </View>

      {isOnline && pendingReports.length > 0 && (
        <TouchableOpacity 
          style={[styles.syncButton, isSyncing && styles.syncingButton]}
          onPress={syncPendingReports}
          disabled={isSyncing}
        >
          <RefreshCw 
            size={14} 
            color="#ffffff" 
            style={isSyncing ? styles.spinning : undefined}
          />
          <Text style={styles.syncButtonText}>
            {isSyncing ? 'Syncing...' : 'Sync Now'}
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 8,
    padding: 12,
    margin: 16,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  statusText: {
    marginLeft: 6,
    fontSize: 14,
    fontWeight: '500',
  },
  separator: {
    width: 1,
    height: 14,
    backgroundColor: '#cbd5e1',
    marginHorizontal: 12,
  },
  pendingText: {
    marginLeft: 6,
    fontSize: 14,
    color: '#f59e0b',
    fontWeight: '500',
  },
  syncButton: {
    backgroundColor: '#2563eb',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 6,
    marginTop: 4,
  },
  syncingButton: {
    backgroundColor: '#64748b',
  },
  syncButtonText: {
    color: '#ffffff',
    fontSize: 13,
    fontWeight: '600',
    marginLeft: 6,
  },
  spinning: {
    // Note: React Native doesn't support CSS animations
    // Animation would need to be implemented with Animated or react-native-reanimated
  },
});