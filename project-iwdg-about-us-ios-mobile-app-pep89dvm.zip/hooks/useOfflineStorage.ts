import AsyncStorage from '@react-native-async-storage/async-storage';
import NetInfo from '@react-native-community/netinfo';
import { useState, useEffect, useCallback } from 'react';
import * as FileSystem from 'expo-file-system';

export interface OfflineReport {
  id: string;
  type: 'sighting' | 'stranding';
  data: {
    species?: string;
    location: string;
    date: string;
    time: string;
    description: string;
    contactName?: string;
    contactEmail?: string;
    contactPhone?: string;
    photos: string[]; // Local file URIs
  };
  timestamp: number;
  synced: boolean;
}

const STORAGE_KEY = 'iwdg_offline_reports';
const PHOTOS_DIR = `${FileSystem.documentDirectory}iwdg_photos/`;

export const useOfflineStorage = () => {
  const [isOnline, setIsOnline] = useState(true);
  const [pendingReports, setPendingReports] = useState<OfflineReport[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);

  // Initialize photos directory
  const ensurePhotosDir = useCallback(async () => {
    const dirInfo = await FileSystem.getInfoAsync(PHOTOS_DIR);
    if (!dirInfo.exists) {
      await FileSystem.makeDirectoryAsync(PHOTOS_DIR, { intermediates: true });
    }
  }, []);

  // Load offline reports from storage
  const loadOfflineReports = useCallback(async () => {
    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      if (stored) {
        const reports: OfflineReport[] = JSON.parse(stored);
        setPendingReports(reports.filter(r => !r.synced));
      }
    } catch (error) {
      console.error('Error loading offline reports:', error);
    }
  }, []);

  // Save report offline
  const saveReportOffline = useCallback(async (
    type: 'sighting' | 'stranding',
    data: Omit<OfflineReport['data'], 'photos'>,
    photos: string[]
  ): Promise<string> => {
    await ensurePhotosDir();
    
    const reportId = `report_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const savedPhotos: string[] = [];

    // Save photos locally
    for (const photoUri of photos) {
      try {
        const filename = `${reportId}_${savedPhotos.length}.jpg`;
        const localUri = `${PHOTOS_DIR}${filename}`;
        await FileSystem.copyAsync({ from: photoUri, to: localUri });
        savedPhotos.push(localUri);
      } catch (error) {
        console.error('Error saving photo locally:', error);
      }
    }

    const newReport: OfflineReport = {
      id: reportId,
      type,
      data: { ...data, photos: savedPhotos },
      timestamp: Date.now(),
      synced: false
    };

    // Update storage
    const existing = await AsyncStorage.getItem(STORAGE_KEY);
    const reports: OfflineReport[] = existing ? JSON.parse(existing) : [];
    reports.push(newReport);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(reports));

    // Update state
    setPendingReports(prev => [...prev, newReport]);

    return reportId;
  }, [ensurePhotosDir]);

  // Upload single report
  const uploadReport = useCallback(async (report: OfflineReport): Promise<boolean> => {
    try {
      const formData = new FormData();
      
      // Add report data
      formData.append('type', report.type);
      formData.append('species', report.data.species || '');
      formData.append('location', report.data.location);
      formData.append('date', report.data.date);
      formData.append('time', report.data.time);
      formData.append('description', report.data.description);
      formData.append('contactName', report.data.contactName || '');
      formData.append('contactEmail', report.data.contactEmail || '');
      formData.append('contactPhone', report.data.contactPhone || '');

      // Add photos
      for (let i = 0; i < report.data.photos.length; i++) {
        const photoUri = report.data.photos[i];
        const fileInfo = await FileSystem.getInfoAsync(photoUri);
        
        if (fileInfo.exists) {
          formData.append(`photo_${i}`, {
            uri: photoUri,
            type: 'image/jpeg',
            name: `photo_${i}.jpg`,
          } as any);
        }
      }

      const endpoint = report.type === 'sighting' 
        ? 'https://api.iwdg.ie/reports/sighting'
        : 'https://api.iwdg.ie/reports/stranding';

      const response = await fetch(endpoint, {
        method: 'POST',
        body: formData,
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (response.ok) {
        // Clean up local photos after successful upload
        for (const photoUri of report.data.photos) {
          try {
            await FileSystem.deleteAsync(photoUri, { idempotent: true });
          } catch (error) {
            console.error('Error deleting local photo:', error);
          }
        }
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error uploading report:', error);
      return false;
    }
  }, []);

  // Sync all pending reports
  const syncPendingReports = useCallback(async () => {
    if (!isOnline || isSyncing || pendingReports.length === 0) return;

    setIsSyncing(true);
    const syncedIds: string[] = [];

    for (const report of pendingReports) {
      const success = await uploadReport(report);
      if (success) {
        syncedIds.push(report.id);
      }
    }

    if (syncedIds.length > 0) {
      // Update storage
      const existing = await AsyncStorage.getItem(STORAGE_KEY);
      const allReports: OfflineReport[] = existing ? JSON.parse(existing) : [];
      const updatedReports = allReports.map(report => 
        syncedIds.includes(report.id) ? { ...report, synced: true } : report
      );
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updatedReports));

      // Update state
      setPendingReports(prev => prev.filter(report => !syncedIds.includes(report.id)));
    }

    setIsSyncing(false);
  }, [isOnline, isSyncing, pendingReports, uploadReport]);

  // Clear synced reports from storage
  const clearSyncedReports = useCallback(async () => {
    const existing = await AsyncStorage.getItem(STORAGE_KEY);
    const allReports: OfflineReport[] = existing ? JSON.parse(existing) : [];
    const unsyncedReports = allReports.filter(report => !report.synced);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(unsyncedReports));
  }, []);

  // Delete specific report
  const deleteOfflineReport = useCallback(async (reportId: string) => {
    const existing = await AsyncStorage.getItem(STORAGE_KEY);
    const allReports: OfflineReport[] = existing ? JSON.parse(existing) : [];
    const report = allReports.find(r => r.id === reportId);
    
    if (report) {
      // Delete local photos
      for (const photoUri of report.data.photos) {
        try {
          await FileSystem.deleteAsync(photoUri, { idempotent: true });
        } catch (error) {
          console.error('Error deleting photo:', error);
        }
      }
      
      // Remove from storage
      const updatedReports = allReports.filter(r => r.id !== reportId);
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updatedReports));
      
      // Update state
      setPendingReports(prev => prev.filter(r => r.id !== reportId));
    }
  }, []);

  // Initialize
  useEffect(() => {
    ensurePhotosDir();
    loadOfflineReports();

    // Monitor network state
    const unsubscribe = NetInfo.addEventListener(state => {
      const wasOffline = !isOnline;
      setIsOnline(!!state.isConnected);
      
      // Auto-sync when coming back online
      if (wasOffline && state.isConnected) {
        setTimeout(syncPendingReports, 1000); // Small delay to ensure connection is stable
      }
    });

    return () => unsubscribe();
  }, [ensurePhotosDir, loadOfflineReports, isOnline, syncPendingReports]);

  return {
    isOnline,
    pendingReports,
    isSyncing,
    saveReportOffline,
    syncPendingReports,
    clearSyncedReports,
    deleteOfflineReport
  };
};