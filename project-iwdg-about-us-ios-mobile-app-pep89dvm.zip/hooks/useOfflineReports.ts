import { useState, useEffect } from 'react'
import AsyncStorage from '@react-native-async-storage/async-storage'
import NetInfo from '@react-native-community/netinfo'

interface QueuedReport {
  id: string
  type: 'sighting' | 'stranding'
  data: {
    location: string
    description: string
    timestamp: string
    images?: string[] // base64 encoded images
  }
  createdAt: string
  attempts: number
}

const QUEUE_KEY = '@iwdg_report_queue'
const MAX_ATTEMPTS = 3

export const useOfflineReports = () => {
  const [queuedReports, setQueuedReports] = useState<QueuedReport[]>([])
  const [isOnline, setIsOnline] = useState(true)
  const [isSyncing, setIsSyncing] = useState(false)

  // Load queued reports from storage
  const loadQueue = async () => {
    try {
      const stored = await AsyncStorage.getItem(QUEUE_KEY)
      if (stored) {
        setQueuedReports(JSON.parse(stored))
      }
    } catch (error) {
      console.error('Failed to load report queue:', error)
    }
  }

  // Save queue to storage
  const saveQueue = async (queue: QueuedReport[]) => {
    try {
      await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(queue))
      setQueuedReports(queue)
    } catch (error) {
      console.error('Failed to save report queue:', error)
    }
  }

  // Add report to offline queue
  const queueReport = async (type: 'sighting' | 'stranding', data: any) => {
    const newReport: QueuedReport = {
      id: Date.now().toString(),
      type,
      data: {
        location: data.location,
        description: data.description,
        timestamp: new Date().toISOString(),
        images: data.images
      },
      createdAt: new Date().toISOString(),
      attempts: 0
    }

    const updatedQueue = [...queuedReports, newReport]
    await saveQueue(updatedQueue)
    return newReport.id
  }

  // Submit report to backend
  const submitReport = async (report: QueuedReport): Promise<boolean> => {
    try {
      const endpoint = report.type === 'sighting' 
        ? 'https://api.iwdg.ie/reports/sighting'
        : 'https://api.iwdg.ie/reports/stranding'

      const formData = new FormData()
      formData.append('location', report.data.location)
      formData.append('description', report.data.description)
      formData.append('timestamp', report.data.timestamp)

      // Add images if any
      if (report.data.images) {
        report.data.images.forEach((imageBase64, index) => {
          const blob = new Blob([Uint8Array.from(atob(imageBase64), c => c.charCodeAt(0))], {
            type: 'image/jpeg'
          })
          formData.append('images', blob as any, `image-${index}.jpg`)
        })
      }

      const response = await fetch(endpoint, {
        method: 'POST',
        body: formData,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })

      return response.ok
    } catch (error) {
      console.error('Failed to submit report:', error)
      return false
    }
  }

  // Sync all queued reports
  const syncQueuedReports = async () => {
    if (!isOnline || isSyncing || queuedReports.length === 0) {
      return
    }

    setIsSyncing(true)
    const updatedQueue = [...queuedReports]

    for (let i = updatedQueue.length - 1; i >= 0; i--) {
      const report = updatedQueue[i]
      
      // Skip if max attempts reached
      if (report.attempts >= MAX_ATTEMPTS) {
        continue
      }

      const success = await submitReport(report)
      
      if (success) {
        // Remove successful report from queue
        updatedQueue.splice(i, 1)
      } else {
        // Increment attempts
        updatedQueue[i].attempts += 1
      }
    }

    await saveQueue(updatedQueue)
    setIsSyncing(false)
  }

  // Remove report from queue
  const removeFromQueue = async (reportId: string) => {
    const updatedQueue = queuedReports.filter(r => r.id !== reportId)
    await saveQueue(updatedQueue)
  }

  // Clear failed reports (max attempts reached)
  const clearFailedReports = async () => {
    const updatedQueue = queuedReports.filter(r => r.attempts < MAX_ATTEMPTS)
    await saveQueue(updatedQueue)
  }

  // Monitor network status
  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(state => {
      setIsOnline(state.isConnected ?? false)
      
      // Auto-sync when connection is restored
      if (state.isConnected && queuedReports.length > 0) {
        setTimeout(() => syncQueuedReports(), 1000) // Small delay to ensure connection is stable
      }
    })

    return unsubscribe
  }, [queuedReports])

  // Load queue on mount
  useEffect(() => {
    loadQueue()
  }, [])

  return {
    queuedReports,
    isOnline,
    isSyncing,
    queueReport,
    syncQueuedReports,
    removeFromQueue,
    clearFailedReports,
    hasQueuedReports: queuedReports.length > 0,
    failedReports: queuedReports.filter(r => r.attempts >= MAX_ATTEMPTS)
  }
}